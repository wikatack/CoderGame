using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Controles : MonoBehaviour
{
    public float rotationSpeed = 100f;

    [SerializeField] private float speed;
    
    void Start()
    {

    }

    
    void Update()
    {
        var vertical = Input.GetAxis("Vertical");
        var Horizontal = Input.GetAxis("Horizontal");
        var e_direction = new Vector3(Horizontal, 0, vertical) * (speed * Time.deltaTime);
        transform.Translate(e_direction);

        Rotate(GetRotationInput());

    }

    private void Rotate(Vector2 p_scrollDelta)
    {
        transform.Rotate(Vector3.up, p_scrollDelta.x * rotationSpeed * Time.deltaTime, Space.Self);
    }

    private Vector2 GetRotationInput()
    {
        var l_mouseX = Input.GetAxis("Mouse X");
        var l_mouseY = Input.GetAxis("Mouse Y");
        return new Vector2(l_mouseX, l_mouseY);
    }

}
