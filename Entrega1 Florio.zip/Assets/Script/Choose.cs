using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEngine;

public class Choose : MonoBehaviour
{
    [SerializeField] private GameObject PSword, PLongsword, Pspear;

    private void Update()
    {
        if (Input.GetKey(KeyCode.Alpha1))
        {
            Instantiate(PLongsword);
            Destroy(gameObject); 
        }

        if (Input.GetKey(KeyCode.Alpha2))
        {
           Instantiate(PSword);
            Destroy(gameObject);
        }


        if (Input.GetKey(KeyCode.Alpha3))
        {
            Instantiate(Pspear);
            Destroy(gameObject);
        }
    }
}
