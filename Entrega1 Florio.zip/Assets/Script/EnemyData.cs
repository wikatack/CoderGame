using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyData : MonoBehaviour
{
    [SerializeField] private float rangeEnemy;
    [SerializeField] private float speed;
    [SerializeField] LayerMask layerPlayer;
    private bool follow;


    void Update()
    {
        follow = Physics.CheckSphere(transform.position, rangeEnemy, layerPlayer);
        if (follow)
        {

        }
    }

    private void OnDrawGizmos()
    {
        Gizmos.color = Color.red;
        Gizmos.DrawWireSphere(transform.position, rangeEnemy);
    }
}
