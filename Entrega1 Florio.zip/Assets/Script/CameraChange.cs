using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Cinemachine;

public class CameraChange : MonoBehaviour
{
    [SerializeField] private CinemachineVirtualCamera m_camera1, m_camera2;
    [SerializeField] private GameObject c_camera1, c_camera2;

    private void Start()
    {
        c_camera1.SetActive(true);
        c_camera2.SetActive(false);
    }

    private void Update()
    {
        if (Input.GetKeyDown("k"))
        {
            AlternateCamera();
        }
    }

    private void AlternateCamera()
    {
        c_camera1.SetActive(!c_camera1.activeSelf);
        c_camera2.SetActive(!c_camera2.activeSelf);

    }
}
