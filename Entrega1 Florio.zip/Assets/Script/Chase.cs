using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Chase : MonoBehaviour, IDamageHealFunction
{
    [SerializeField] private float TurningSpeed; 
    [SerializeField] private Transform target;
    [SerializeField] private float RangeToChase;
    public float s_damage;
    [SerializeField] private float maxlife;
    [SerializeField] private LayerMask damageable;
    private float life;
    private float maxTime = 1;
    private float time;

    private void Awake()
    {
        life = maxlife;
        time = maxTime;
    }

    void Update()
    {
        var diffVector = target.position - transform.position; 
        Chasing();

        Quaternion NewRotation = Quaternion.LookRotation(diffVector.normalized);
        transform.rotation = Quaternion.Lerp(transform.rotation, NewRotation, Time.deltaTime * TurningSpeed);
    }

    public void SetTarget(Transform player)
    {
        target = player;
    }

    public void TakeDamage(float p_damage)
    {
        life -= p_damage;
        if (life <= 0)
        {
            Destroy(gameObject);
        }
    }

    private void Chasing()
    {
        var diffVector = target.position - transform.position;

        if (RangeToChase > diffVector.magnitude)
        {
            time -= Time.deltaTime;
            if (time<=0)
            {
                transform.LookAt(target);
                Move(diffVector.normalized);

            }
        }
        else
        {
            time = maxTime;
        }
         if (diffVector.magnitude < 3)
        {
          transform.LookAt(target);
        }
    }
    
    private void Move(Vector3 direction)
    {
        var Speed = 1.5f;   
        transform.position += direction * Speed * Time.deltaTime; 
    }

}
