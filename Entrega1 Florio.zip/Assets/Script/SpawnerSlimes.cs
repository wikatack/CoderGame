using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SpawnerSlimes : MonoBehaviour
{
    [SerializeField] private Chase slime;
    [SerializeField] private float time;
    [SerializeField] private Transform p_target;
    private float timeToSpawn;

    private void Awake()
    {
        timeToSpawn = time;
    }
    void Update()
    {
        timeToSpawn -= Time.deltaTime;
        if (timeToSpawn <= 0)
        {
            Spawn();
           
        }
    }

    private void Spawn()
    {
        Chase enemy = Instantiate(slime, transform.position, Quaternion.identity);
        enemy.SetTarget(p_target);
        timeToSpawn = time;
    }
}
